export type UserRole = "creator" | "brand";

export interface User {
  id: string; // auth.uid
  email: string;
  name: string;
  avatar: string;
  role: UserRole;
  createdAt: number;
  lastLogin: number;
}

export interface CreatorProfile {
  userId: string;
  username: string;
  bio: string;
  category: string;
  skills: string[];
  location: string;
  portfolio: string[];
  socialLinks: Record<string, string>;
  cryovaScore: number;
}

export interface BrandProfile {
  userId: string;
  companyName: string;
  logo: string;
  industry: string;
  description: string;
  website: string;
}

export interface Post {
  id: string;
  userId: string;
  content: string;
  media: string[];
  createdAt: number;
}

export interface Campaign {
  id: string;
  brandId: string;
  title: string;
  description: string;
  budget: string;
  requirements: string;
  createdAt: number;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  message: string;
  timestamp: number;
}
